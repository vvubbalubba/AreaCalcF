# Area Library #

## What is this? ##
The module allows you to calculate area of figure by it's parameters.

----------


### Using ###


Using the library is as simple and convenient as possible:

Let's import it first:
First, import everything from the library (use the `from `...` import *` construct).

Examples of all operations:

Calculating circle area with radius=5 using the `calc_area()` function:

    s = Area(figure_type="circle", {"r": 5}).calc_area()

----------


## Developer ##
wubbalubba